#[cfg(windows)]
use super::windows_process::Child;
use std::io::{BufRead, BufReader, Write};
#[cfg(target_os = "linux")]
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
#[cfg(not(windows))]
use std::process::{Child, Command, Stdio};
use std::sync::Arc;
use std::time::Duration;

use super::discovery::discover_cdp_url;
use crate::ca_bundle::CaBundle;

pub struct ChromeProcess {
    child: Child,
    pub ws_url: String,
    temp_user_data_dir: Option<PathBuf>,
    temp_nss_home: Option<PreparedNssHome>,
    /// On Unix, the process group ID used to kill the entire Chrome process tree.
    #[cfg(unix)]
    pgid: Option<i32>,
    /// Private Xvfb server auto-started for headed mode on displayless Linux
    /// hosts. Dropped (and killed) after the Chrome tree is torn down.
    #[cfg(target_os = "linux")]
    xvfb: Option<XvfbServer>,
}

struct PreparedNssHomeInner {
    path: PathBuf,
}

impl Drop for PreparedNssHomeInner {
    fn drop(&mut self) {
        for attempt in 0..3 {
            match std::fs::remove_dir_all(&self.path) {
                Ok(()) => break,
                Err(_) if attempt < 2 => std::thread::sleep(Duration::from_millis(100)),
                Err(e) => {
                    let _ = writeln!(
                        std::io::stderr(),
                        "Warning: failed to clean up temporary CA trust store {}: {}",
                        self.path.display(),
                        e
                    );
                }
            }
        }
    }
}

#[derive(Clone)]
pub(crate) struct PreparedNssHome {
    inner: Arc<PreparedNssHomeInner>,
}

impl PreparedNssHome {
    fn path(&self) -> &Path {
        &self.inner.path
    }
}

impl ChromeProcess {
    pub fn kill(&mut self) {
        let _ = self.child.kill();
        // On Unix, kill the entire process group to ensure Chrome helper
        // processes (GPU, renderer, utility, crashpad) are also terminated.
        // This prevents orphaned Chrome processes from blocking the user's
        // normal Chrome (issue #1113).
        #[cfg(unix)]
        if let Some(pgid) = self.pgid {
            unsafe {
                libc::kill(-pgid, libc::SIGKILL);
            }
        }
        let _ = self.child.wait();
    }

    /// Returns the OS process ID of the Chrome child process.
    pub fn id(&self) -> u32 {
        self.child.id()
    }

    /// Non-blocking check whether Chrome has exited.
    /// Returns `true` if the process has exited (and reaps it), `false` if still running.
    pub fn has_exited(&mut self) -> bool {
        matches!(self.child.try_wait(), Ok(Some(_)) | Err(_))
    }

    /// Wait for Chrome to exit on its own (after Browser.close CDP command),
    /// falling back to kill() if it doesn't exit within the timeout.
    /// This allows Chrome to flush cookies and other state to the user-data-dir.
    pub fn wait_or_kill(&mut self, timeout: Duration) {
        let start = std::time::Instant::now();
        let poll_interval = Duration::from_millis(50);

        while start.elapsed() < timeout {
            match self.child.try_wait() {
                Ok(Some(_)) => return,
                Ok(None) => std::thread::sleep(poll_interval),
                Err(_) => break,
            }
        }

        self.kill();
    }
}

impl Drop for ChromeProcess {
    fn drop(&mut self) {
        self.kill();
        if let Some(ref dir) = self.temp_user_data_dir {
            for attempt in 0..3 {
                match std::fs::remove_dir_all(dir) {
                    Ok(()) => break,
                    Err(_) if attempt < 2 => {
                        std::thread::sleep(Duration::from_millis(100));
                    }
                    Err(e) => {
                        // Use write! instead of eprintln! to avoid panicking
                        // if the daemon's stderr pipe is broken (parent dropped it).
                        let _ = writeln!(
                            std::io::stderr(),
                            "Warning: failed to clean up temp profile {}: {}",
                            dir.display(),
                            e
                        );
                    }
                }
            }
        }
    }
}

/// A private Xvfb virtual display owned by one Chrome process.
///
/// Headed Chrome on Linux needs an X display, and some workloads need headed
/// mode on hosts that have none: headless Chrome cannot composite WebGPU
/// canvas presentation into screenshots (upstream limitation), so WebGPU
/// capture requires a real or virtual display. When headed mode is requested,
/// no DISPLAY is set, and Xvfb is installed, launch spawns a private server
/// instead of failing. Opt out with AGENT_BROWSER_NO_XVFB=1.
///
/// The server requires MIT-MAGIC-COOKIE-1 authentication (`-auth`): without
/// authorization records an X server allows any local user to connect, which
/// on a shared host would let other accounts observe the browser and inject
/// input. Only the paired Chrome process receives the cookie via XAUTHORITY.
#[cfg(target_os = "linux")]
struct XvfbServer {
    child: Child,
    display: String,
    auth_file: PathBuf,
}

#[cfg(target_os = "linux")]
impl Drop for XvfbServer {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_file(&self.auth_file);
    }
}

/// Write an .Xauthority file containing one FamilyWild MIT-MAGIC-COOKIE-1
/// record with a random cookie, created 0600.
///
/// FamilyWild (0xffff, empty address and display number) matches any display,
/// which sidesteps a chicken-and-egg with `-displayfd`: the display number is
/// only known after the server starts, but the auth file must exist before.
/// The server side is unaffected -- X servers compare only the cookie bytes
/// for MIT-MAGIC-COOKIE-1 -- and client libraries (libXau/libxcb) accept
/// FamilyWild entries for any display.
#[cfg(target_os = "linux")]
fn write_xauth_file(path: &Path) -> std::io::Result<()> {
    use std::io::Write as _;
    use std::os::unix::fs::OpenOptionsExt;

    // Uuid v4 carries 122 random bits in 16 bytes.
    let cookie = uuid::Uuid::new_v4();
    let name = b"MIT-MAGIC-COOKIE-1";

    // .Xauthority records are sequences of big-endian u16-length-prefixed
    // fields: family, address, display number, auth name, auth data.
    let mut buf: Vec<u8> = Vec::with_capacity(10 + name.len() + 16);
    buf.extend_from_slice(&0xffffu16.to_be_bytes()); // FamilyWild
    buf.extend_from_slice(&0u16.to_be_bytes()); // address: empty
    buf.extend_from_slice(&0u16.to_be_bytes()); // display number: empty
    buf.extend_from_slice(&(name.len() as u16).to_be_bytes());
    buf.extend_from_slice(name);
    buf.extend_from_slice(&16u16.to_be_bytes());
    buf.extend_from_slice(cookie.as_bytes());

    let mut file = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(path)?;
    file.write_all(&buf)
}

#[cfg(target_os = "linux")]
/// True when the launch will effectively run headed and therefore needs a
/// display. This must track `build_chrome_args`: extensions suppress
/// `--headless=new` (content scripts are not injected headless), so a
/// nominally headless launch with extensions is headed in practice.
fn xvfb_applicable(options: &LaunchOptions) -> bool {
    !options.effectively_headless()
}

#[cfg(target_os = "linux")]
fn maybe_start_xvfb(options: &LaunchOptions) -> Option<XvfbServer> {
    if !xvfb_applicable(options) {
        return None;
    }
    if std::env::var("DISPLAY")
        .map(|d| !d.is_empty())
        .unwrap_or(false)
    {
        return None;
    }
    if options.no_xvfb {
        return None;
    }

    let (w, h) = options.viewport_size.unwrap_or((1280, 720));

    // Private MIT-MAGIC-COOKIE-1 authority file; passed to the server via
    // -auth and to the paired Chrome via XAUTHORITY. Removed on Drop.
    let auth_file =
        std::env::temp_dir().join(format!("agent-browser-xauth-{}", uuid::Uuid::new_v4()));
    if write_xauth_file(&auth_file).is_err() {
        return None;
    }
    let cleanup_auth = |path: &Path| {
        let _ = std::fs::remove_file(path);
    };

    // Let Xvfb allocate the display itself with -displayfd: the server binds
    // the first free display atomically and writes its number to the given
    // fd. Probing /tmp/.X11-unix for free numbers is racy -- two concurrent
    // sessions could adopt the same display, and closing one would kill the
    // display under the other session's Chrome.
    use std::io::Read;
    use std::os::unix::io::FromRawFd;

    let mut fds = [0i32; 2];
    // SAFETY: plain pipe(2); both ends are wrapped in File below so they are
    // closed on every path out of this function.
    if unsafe { libc::pipe(fds.as_mut_ptr()) } != 0 {
        cleanup_auth(&auth_file);
        return None;
    }
    // SAFETY: fds are fresh from pipe(2) and owned exclusively here.
    let mut read_end = unsafe { std::fs::File::from_raw_fd(fds[0]) };
    let write_end = unsafe { std::fs::File::from_raw_fd(fds[1]) };

    let mut child = match Command::new("Xvfb")
        .args([
            "-displayfd",
            &fds[1].to_string(),
            "-screen",
            "0",
            &format!("{}x{}x24", w, h),
            "-nolisten",
            "tcp",
            "-auth",
            &auth_file.display().to_string(),
        ])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
    {
        Ok(c) => c,
        // Xvfb not installed (or not executable): headed launch proceeds
        // without a display and surfaces Chrome's own error.
        Err(_) => {
            cleanup_auth(&auth_file);
            return None;
        }
    };
    // Drop the parent's copy of the write end so the read below sees EOF as
    // soon as Xvfb exits without reporting a display.
    drop(write_end);

    // SAFETY: read_end owns fds[0]; make it non-blocking so a wedged Xvfb
    // cannot stall the launch past the deadline.
    unsafe {
        let flags = libc::fcntl(fds[0], libc::F_GETFL);
        libc::fcntl(fds[0], libc::F_SETFL, flags | libc::O_NONBLOCK);
    }

    let deadline = std::time::Instant::now() + Duration::from_secs(5);
    let mut buf: Vec<u8> = Vec::new();
    loop {
        let mut chunk = [0u8; 16];
        match read_end.read(&mut chunk) {
            // EOF: Xvfb exited without binding a display.
            Ok(0) => break,
            Ok(n) => {
                buf.extend_from_slice(&chunk[..n]);
                if let Some(pos) = buf.iter().position(|&b| b == b'\n') {
                    match String::from_utf8_lossy(&buf[..pos]).trim().parse::<u32>() {
                        Ok(num) => {
                            return Some(XvfbServer {
                                child,
                                display: format!(":{}", num),
                                auth_file,
                            });
                        }
                        Err(_) => break,
                    }
                }
            }
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                if std::time::Instant::now() >= deadline {
                    break;
                }
                std::thread::sleep(Duration::from_millis(50));
            }
            Err(_) => break,
        }
    }
    let _ = child.kill();
    let _ = child.wait();
    cleanup_auth(&auth_file);
    None
}

#[derive(Clone)]
pub struct LaunchOptions {
    pub headless: bool,
    pub executable_path: Option<String>,
    pub proxy: Option<String>,
    pub proxy_bypass: Option<String>,
    pub proxy_username: Option<String>,
    pub proxy_password: Option<String>,
    pub profile: Option<String>,
    pub args: Vec<String>,
    pub allow_file_access: bool,
    pub extensions: Option<Vec<String>>,
    pub storage_state: Option<String>,
    pub user_agent: Option<String>,
    pub ignore_https_errors: bool,
    pub ca_cert: Option<String>,
    pub(crate) ca_bundle: Option<CaBundle>,
    pub(crate) ca_cert_digest: Option<[u8; 32]>,
    pub(crate) prepared_nss_home: Option<PreparedNssHome>,
    pub color_scheme: Option<String>,
    pub download_path: Option<String>,
    /// Hide native scrollbars in headless Chromium screenshots by launching
    /// Chrome with `--hide-scrollbars`.
    pub hide_scrollbars: bool,
    /// Initial viewport dimensions used for `--window-size` so the content
    /// area matches the desired viewport from the start.
    pub viewport_size: Option<(u32, u32)>,
    /// When true, omit `--password-store=basic` and `--use-mock-keychain` so
    /// Chrome uses the real system keychain. Set automatically when launching
    /// with a copied Chrome profile.
    pub use_real_keychain: bool,
    /// Enable WebGPU in environments where Chrome does not expose it by
    /// default (headless, GPU-less containers, blocklisted GPUs). On Linux
    /// this routes WebGPU through SwiftShader's software Vulkan with software
    /// compositing so it works without a GPU or display.
    pub webgpu: bool,
    /// Enable Chrome's experimental WebMCP implementation for agent-browser
    /// managed sessions. Enabled by default and disabled with `--no-webmcp`.
    pub webmcp: bool,
    /// Disable automatic Xvfb for headed launches on displayless Linux
    /// hosts (AGENT_BROWSER_NO_XVFB). Carried as a launch option so the
    /// CLI's current environment wins over the env a long-lived daemon was
    /// spawned with.
    pub no_xvfb: bool,
    /// Restrict WebRTC to proxied transports so direct UDP cannot bypass the
    /// HTTP domain filter. Enabled automatically with `--allowed-domains`.
    pub restrict_webrtc: bool,
}

impl LaunchOptions {
    /// Whether Chrome will actually run headless after applying launch rules.
    ///
    /// Extensions force headed mode because Chrome does not inject their
    /// content scripts under `--headless=new`.
    pub(crate) fn effectively_headless(&self) -> bool {
        self.headless
            && !self
                .extensions
                .as_ref()
                .is_some_and(|exts| !exts.is_empty())
    }
}

impl Default for LaunchOptions {
    fn default() -> Self {
        Self {
            headless: true,
            executable_path: None,
            proxy: None,
            proxy_bypass: None,
            proxy_username: None,
            proxy_password: None,
            profile: None,
            args: Vec::new(),
            allow_file_access: false,
            extensions: None,
            storage_state: None,
            user_agent: None,
            ignore_https_errors: false,
            ca_cert: None,
            ca_bundle: None,
            ca_cert_digest: None,
            prepared_nss_home: None,
            color_scheme: None,
            download_path: None,
            hide_scrollbars: true,
            viewport_size: None,
            use_real_keychain: false,
            webgpu: false,
            webmcp: true,
            no_xvfb: false,
            restrict_webrtc: false,
        }
    }
}

struct ChromeArgs {
    args: Vec<String>,
    user_data_dir: PathBuf,
    temp_user_data_dir: Option<PathBuf>,
}

fn build_chrome_args(options: &LaunchOptions) -> Result<ChromeArgs, String> {
    // Chrome only honors the last --enable-features switch on the command
    // line, so every feature must be collected into a single flag.
    let mut enable_features: Vec<String> = vec![
        "NetworkService".to_string(),
        "NetworkServiceInProcess".to_string(),
    ];
    if options.webmcp {
        enable_features.push("WebMCPTesting".to_string());
        enable_features.push("DevToolsWebMCPSupport".to_string());
    }
    if options.webgpu && cfg!(target_os = "linux") {
        enable_features.push("Vulkan".to_string());
    }

    // User-supplied --enable-features values are merged into that single
    // flag too: appending them as a second switch would silently clobber
    // the preset's features (e.g. drop the WebGPU preset's Vulkan). To turn
    // a preset feature off, pass --disable-features=<name>, which Chrome
    // resolves as disabled.
    let mut user_args: Vec<String> = Vec::new();
    for arg in &options.args {
        if let Some(values) = arg.strip_prefix("--enable-features=") {
            for feature in values.split(',').map(str::trim).filter(|f| !f.is_empty()) {
                if !enable_features.iter().any(|f| f == feature) {
                    enable_features.push(feature.to_string());
                }
            }
        } else {
            user_args.push(arg.clone());
        }
    }

    let mut args = vec![
        "--remote-debugging-port=0".to_string(),
        "--no-first-run".to_string(),
        "--no-default-browser-check".to_string(),
        "--disable-background-networking".to_string(),
        "--disable-backgrounding-occluded-windows".to_string(),
        "--disable-component-update".to_string(),
        "--disable-default-apps".to_string(),
        "--disable-hang-monitor".to_string(),
        "--disable-popup-blocking".to_string(),
        "--disable-prompt-on-repost".to_string(),
        "--disable-sync".to_string(),
        "--disable-features=Translate".to_string(),
        format!("--enable-features={}", enable_features.join(",")),
        "--metrics-recording-only".to_string(),
    ];

    if options.webgpu {
        // WebGPU is not exposed in headless or GPU-blocklisted environments
        // unless explicitly enabled.
        args.push("--enable-unsafe-webgpu".to_string());
        if cfg!(target_os = "linux") {
            // Route WebGPU through SwiftShader's software Vulkan and disable
            // Vulkan surface presentation (software compositing). This
            // combination produces real pixels in GPU-less containers and CI;
            // hardware-Vulkan users can override via --args (later switches
            // win). macOS and Windows use the hardware Metal/D3D backends.
            args.push("--use-angle=vulkan".to_string());
            args.push("--use-vulkan=swiftshader".to_string());
            args.push("--use-webgpu-adapter=swiftshader".to_string());
            args.push("--disable-vulkan-surface".to_string());
        }
    }

    if !options.use_real_keychain {
        args.push("--password-store=basic".to_string());
        args.push("--use-mock-keychain".to_string());
    }

    let effectively_headless = options.effectively_headless();

    // Extensions require headed mode in native Chrome (content scripts are not
    // injected in headless mode).  Skip --headless when extensions are loaded.
    if effectively_headless {
        args.push("--headless=new".to_string());
        // Linux paints native scrollbars into viewport screenshots unless
        // Chrome is launched with this flag. `--hide-scrollbars` is
        // presence-based, so agent-browser exposes --hide-scrollbars false
        // as the public opt-out instead of forwarding a fake inverse switch.
        if options.hide_scrollbars {
            args.push("--hide-scrollbars".to_string());
        }
        // Enable SwiftShader software rendering in headless mode.  This
        // prevents silent crashes in environments where GPU drivers are
        // missing or restricted (VMs, containers, some cloud machines)
        // while preserving WebGL support.  Playwright uses the same flag.
        args.push("--enable-unsafe-swiftshader".to_string());
    }

    if let Some(ref proxy) = options.proxy {
        args.push(format!("--proxy-server={}", proxy));
    }

    if let Some(ref bypass) = options.proxy_bypass {
        args.push(format!("--proxy-bypass-list={}", bypass));
    }

    let (user_data_dir, temp_user_data_dir) = if let Some(ref profile) = options.profile {
        let expanded = expand_tilde(profile);
        let dir = PathBuf::from(&expanded);
        args.push(format!("--user-data-dir={}", expanded));
        (dir, None)
    } else {
        let dir =
            std::env::temp_dir().join(format!("agent-browser-chrome-{}", uuid::Uuid::new_v4()));
        std::fs::create_dir_all(&dir)
            .map_err(|e| format!("Failed to create temp profile dir: {}", e))?;
        args.push(format!("--user-data-dir={}", dir.display()));
        (dir.clone(), Some(dir))
    };

    if options.ignore_https_errors {
        args.push("--ignore-certificate-errors".to_string());
    }

    if options.allow_file_access {
        args.push("--allow-file-access-from-files".to_string());
        args.push("--allow-file-access".to_string());
    }

    if let Some(ref exts) = options.extensions {
        if !exts.is_empty() {
            let ext_list = exts.join(",");
            args.push(format!("--load-extension={}", ext_list));
            args.push(format!("--disable-extensions-except={}", ext_list));
        }
    }

    let has_window_size = options
        .args
        .iter()
        .any(|a| a.starts_with("--start-maximized") || a.starts_with("--window-size="));

    if !has_window_size && effectively_headless {
        let (w, h) = options.viewport_size.unwrap_or((1280, 720));
        args.push(format!("--window-size={},{}", w, h));
    }

    args.extend(user_args);

    if options.restrict_webrtc {
        // Append this after user and plugin arguments so an unsafe custom
        // policy cannot override the containment setting. JavaScript-level
        // RTCPeerConnection blocking is the primary control; this prevents
        // direct UDP traffic if page code obtains a native constructor.
        args.retain(|arg| !arg.starts_with("--force-webrtc-ip-handling-policy="));
        args.push("--force-webrtc-ip-handling-policy=disable_non_proxied_udp".to_string());
    }

    if should_disable_sandbox(&args) {
        args.push("--no-sandbox".to_string());
    }

    if should_disable_dev_shm(&args) {
        args.push("--disable-dev-shm-usage".to_string());
    }

    Ok(ChromeArgs {
        args,
        user_data_dir,
        temp_user_data_dir,
    })
}

#[cfg(target_os = "linux")]
pub(crate) fn prepare_nss_home(ca_cert: &CaBundle) -> Result<PreparedNssHome, String> {
    use std::os::unix::fs::{symlink, PermissionsExt};

    let home = std::env::temp_dir().join(format!("agent-browser-nss-{}", uuid::Uuid::new_v4()));
    let pki_dir = home.join(".local/share/pki");
    let db_dir = pki_dir.join("nssdb");

    let result = (|| {
        std::fs::create_dir_all(&db_dir)
            .map_err(|e| format!("Failed to create temporary CA trust store: {e}"))?;
        std::fs::set_permissions(&home, std::fs::Permissions::from_mode(0o700))
            .map_err(|e| format!("Failed to secure temporary CA trust store: {e}"))?;
        symlink(".local/share/pki", home.join(".pki"))
            .map_err(|e| format!("Failed to configure temporary CA trust store: {e}"))?;

        let db = format!("sql:{}", db_dir.display());
        run_certutil(
            &["-N", "--empty-password", "-d", &db],
            "initialize the NSS database",
        )?;

        for (index, cert) in ca_cert.certificates().iter().enumerate() {
            let cert_path = home.join(format!("ca-{index}.der"));
            std::fs::write(&cert_path, cert.as_ref())
                .map_err(|e| format!("Failed to stage CA certificate for import: {e}"))?;
            std::fs::set_permissions(&cert_path, std::fs::Permissions::from_mode(0o600))
                .map_err(|e| format!("Failed to secure staged CA certificate: {e}"))?;
            let nickname = format!("agent-browser-ca-{index}");
            let cert_path_arg = cert_path.display().to_string();
            let import_result = run_certutil(
                &[
                    "-A",
                    "-d",
                    &db,
                    "-t",
                    "C,,",
                    "-n",
                    &nickname,
                    "-i",
                    &cert_path_arg,
                ],
                "import the CA certificate",
            );
            let _ = std::fs::remove_file(&cert_path);
            import_result?;
        }

        Ok(())
    })();

    if let Err(error) = result {
        let _ = std::fs::remove_dir_all(&home);
        return Err(error);
    }

    Ok(PreparedNssHome {
        inner: Arc::new(PreparedNssHomeInner { path: home }),
    })
}

#[cfg(not(target_os = "linux"))]
pub(crate) fn prepare_nss_home(_ca_cert: &CaBundle) -> Result<PreparedNssHome, String> {
    Err("--ca-cert is currently supported only on Linux".to_string())
}

fn resolve_prepared_nss_home(options: &LaunchOptions) -> Result<Option<PreparedNssHome>, String> {
    if let Some(home) = options.prepared_nss_home.clone() {
        return Ok(Some(home));
    }

    let ca_bundle = match options.ca_bundle.clone() {
        Some(bundle) => Some(bundle),
        None => options
            .ca_cert
            .as_deref()
            .map(crate::ca_bundle::load)
            .transpose()?,
    };

    ca_bundle.as_ref().map(prepare_nss_home).transpose()
}

#[cfg(target_os = "linux")]
fn run_certutil(args: &[&str], action: &str) -> Result<(), String> {
    let output = Command::new("certutil").args(args).output().map_err(|e| {
        format!(
            "Failed to {action}: could not run certutil ({e}). Run agent-browser install --with-deps, or install libnss3-tools on Debian/Ubuntu or nss-tools on RPM Linux."
        )
    })?;
    if output.status.success() {
        return Ok(());
    }

    let detail = String::from_utf8_lossy(&output.stderr).trim().to_string();
    if detail.is_empty() {
        Err(format!(
            "Failed to {action}: certutil exited with {}. Run agent-browser install --with-deps, or repair libnss3-tools on Debian/Ubuntu or nss-tools on RPM Linux.",
            output.status
        ))
    } else {
        Err(format!("Failed to {action}: {detail}"))
    }
}

fn terminate_launched_chrome(child: &mut Child) {
    let _ = child.kill();
    #[cfg(unix)]
    unsafe {
        libc::kill(-(child.id() as i32), libc::SIGKILL);
    }
    let _ = child.wait();
}

pub fn launch_chrome(options: &LaunchOptions) -> Result<ChromeProcess, String> {
    let chrome_path = match &options.executable_path {
        Some(p) => PathBuf::from(p),
        None => find_chrome().ok_or_else(|| {
            let cache_dir = crate::install::get_browsers_dir();
            format!(
                "Chrome not found. Checked:\n  \
                 - agent-browser cache: {}\n  \
                 - System Chrome installations\n  \
                 - Puppeteer browser cache\n  \
                 - Playwright browser cache\n\
                 Run `agent-browser install` to download Chrome, or use --executable-path.",
                cache_dir.display()
            )
        })?,
    };

    // Profile name preprocessing: if --profile is a Chrome profile name (not a
    // path), resolve it to a directory, copy the profile to a temp dir, and
    // rewrite options so the retry loop uses the copied profile.
    let mut resolved_options: Option<LaunchOptions> = None;
    let mut profile_temp_dir: Option<PathBuf> = None;

    if let Some(ref profile) = options.profile {
        if is_chrome_profile_name(profile) {
            let user_data_dir = find_chrome_user_data_dir().ok_or_else(|| {
                "No Chrome user data directory found. Cannot resolve profile name.\n\
                 If you meant a directory path, use a full path (e.g., /path/to/profile)."
                    .to_string()
            })?;
            let resolved = resolve_chrome_profile(&user_data_dir, profile)?;
            let temp_path = copy_chrome_profile(&user_data_dir, &resolved)?;

            let mut opts = options.clone();
            opts.profile = Some(temp_path.display().to_string());
            opts.use_real_keychain = true;
            opts.args.push(format!("--profile-directory={}", resolved));
            profile_temp_dir = Some(temp_path);
            resolved_options = Some(opts);
        }
    }

    let effective_options = resolved_options.as_ref().unwrap_or(options);

    let max_attempts = 3;
    let mut last_err = String::new();

    for attempt in 1..=max_attempts {
        match try_launch_chrome(&chrome_path, effective_options) {
            Ok(mut process) => {
                // Transfer profile temp dir ownership to ChromeProcess for cleanup on Drop.
                // The try_launch_chrome temp_user_data_dir is None here because we set profile
                // to the temp path (treated as a user-supplied path, no second temp dir).
                if let Some(ref dir) = profile_temp_dir {
                    process.temp_user_data_dir = Some(dir.clone());
                }
                return Ok(process);
            }
            Err(e) => {
                last_err = e;
                if attempt < max_attempts {
                    // Use write! instead of eprintln! to avoid panicking
                    // if the daemon's stderr pipe is broken (parent dropped it).
                    let _ = writeln!(
                        std::io::stderr(),
                        "[chrome] Launch attempt {}/{} failed, retrying in 500ms...",
                        attempt,
                        max_attempts
                    );
                    std::thread::sleep(Duration::from_millis(500));
                }
            }
        }
    }

    // All retries failed: clean up profile temp dir if we created one
    if let Some(ref dir) = profile_temp_dir {
        let _ = std::fs::remove_dir_all(dir);
    }

    Err(last_err)
}

fn try_launch_chrome(chrome_path: &Path, options: &LaunchOptions) -> Result<ChromeProcess, String> {
    let ChromeArgs {
        args,
        user_data_dir,
        temp_user_data_dir,
    } = build_chrome_args(options)?;

    // Mitigate stale DevToolsActivePort risk (e.g., previous crash left it behind).
    // Puppeteer does similar cleanup before spawning.
    let _ = std::fs::remove_file(user_data_dir.join("DevToolsActivePort"));

    let cleanup_temp_dir = |dir: &Option<PathBuf>| {
        if let Some(ref d) = dir {
            let _ = std::fs::remove_dir_all(d);
        }
    };

    #[cfg(target_os = "linux")]
    let temp_nss_home = match resolve_prepared_nss_home(options) {
        Ok(home) => home,
        Err(error) => {
            cleanup_temp_dir(&temp_user_data_dir);
            return Err(error);
        }
    };
    #[cfg(not(target_os = "linux"))]
    let temp_nss_home: Option<PreparedNssHome> = None;

    #[cfg(target_os = "linux")]
    let xvfb = maybe_start_xvfb(options);

    #[cfg(not(windows))]
    let mut cmd = Command::new(chrome_path);
    #[cfg(not(windows))]
    cmd.args(&args)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::piped());

    // Scope the virtual display and its auth cookie to the Chrome child;
    // the daemon's own environment is left untouched.
    #[cfg(target_os = "linux")]
    if let Some(ref x) = xvfb {
        cmd.env("DISPLAY", &x.display);
        cmd.env("XAUTHORITY", &x.auth_file);
    }
    #[cfg(target_os = "linux")]
    if let Some(ref home) = temp_nss_home {
        cmd.env("HOME", home.path());
        cmd.env("XDG_DATA_HOME", home.path().join(".local/share"));
    }

    // Place Chrome in its own process group so we can kill the entire tree
    // (main process + GPU/renderer/utility/crashpad helpers) with a single
    // killpg(), preventing orphaned processes (issue #1113).
    //
    // NOTE: Do NOT use PR_SET_PDEATHSIG here. Chrome is spawned via
    // tokio::task::spawn_blocking, and PR_SET_PDEATHSIG fires when the
    // *thread* that forked the child exits, not the process. Tokio reaps
    // idle blocking threads after ~10s, which kills Chrome (issue #1157).
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        // SAFETY: pre_exec runs between fork() and exec() in the child.
        // setpgid is async-signal-safe.
        unsafe {
            cmd.pre_exec(|| {
                libc::setpgid(0, 0);
                Ok(())
            });
        }
    }

    #[cfg(not(windows))]
    let spawned = cmd.spawn();
    #[cfg(windows)]
    let spawned = Child::spawn(chrome_path, &args, options.effectively_headless());
    let mut child = spawned.map_err(|e| {
        cleanup_temp_dir(&temp_user_data_dir);
        format!("Failed to launch Chrome at {:?}: {}", chrome_path, e)
    })?;

    // Shared overall deadline so we don't double-wait (poll + stderr fallback).
    let deadline = std::time::Instant::now() + Duration::from_secs(30);

    // Primary path: use DevToolsActivePort written into user-data-dir.
    // This is more reliable on Windows than scraping stderr for "DevTools listening on ...",
    // which can be missing/empty depending on how Chrome is launched.
    let ws_url = match wait_for_devtools_active_port(&mut child, &user_data_dir, deadline) {
        Ok(url) => url,
        Err(primary_err) => {
            // Fallback: scrape stderr (legacy behavior) for better diagnostics.
            let stderr = child.stderr.take().ok_or_else(|| {
                terminate_launched_chrome(&mut child);
                cleanup_temp_dir(&temp_user_data_dir);
                "Failed to capture Chrome stderr".to_string()
            })?;
            let reader = BufReader::new(stderr);
            match wait_for_ws_url_until(reader, deadline) {
                Ok(url) => url,
                Err(fallback_err) => {
                    terminate_launched_chrome(&mut child);
                    cleanup_temp_dir(&temp_user_data_dir);
                    return Err(format!(
                        "{}\n(also tried parsing stderr) {}",
                        primary_err, fallback_err
                    ));
                }
            }
        }
    };

    // Chrome blocks on stderr writes once the pipe buffer fills, so keep draining it
    // after readiness. The fallback path has already taken stderr.
    if let Some(stderr) = child.stderr.take() {
        let _ = std::thread::Builder::new()
            .name("chrome-stderr-drain".into())
            .spawn(move || {
                let mut stderr = stderr;
                let _ = std::io::copy(&mut stderr, &mut std::io::sink());
            });
    }

    #[cfg(unix)]
    let pgid = {
        let pid = child.id() as i32;
        // The child called setpgid(0,0) via process_group(0), so its PGID
        // equals its own PID.
        Some(pid)
    };

    Ok(ChromeProcess {
        child,
        ws_url,
        temp_user_data_dir,
        temp_nss_home,
        #[cfg(unix)]
        pgid,
        #[cfg(target_os = "linux")]
        xvfb,
    })
}

fn wait_for_devtools_active_port(
    child: &mut Child,
    user_data_dir: &Path,
    deadline: std::time::Instant,
) -> Result<String, String> {
    let poll_interval = Duration::from_millis(50);

    while std::time::Instant::now() <= deadline {
        if let Ok(Some(status)) = child.try_wait() {
            // Chrome exited before writing DevToolsActivePort -- report the
            // exit code so the caller can surface it alongside stderr output.
            let code = status
                .code()
                .map(|c| format!("{}", c))
                .unwrap_or_else(|| "unknown".to_string());
            return Err(format!(
                "Chrome exited early (exit code: {}) without writing DevToolsActivePort",
                code
            ));
        }

        if let Some((port, ws_path)) = read_devtools_active_port(user_data_dir) {
            let ws_url = format!("ws://127.0.0.1:{}{}", port, ws_path);
            return Ok(ws_url);
        }

        std::thread::sleep(poll_interval);
    }

    Err("Timeout waiting for DevToolsActivePort".to_string())
}

fn wait_for_ws_url_until(
    reader: impl BufRead,
    deadline: std::time::Instant,
) -> Result<String, String> {
    let prefix = "DevTools listening on ";
    let mut stderr_lines: Vec<String> = Vec::new();

    for line in reader.lines() {
        if std::time::Instant::now() > deadline {
            return Err(chrome_launch_error(
                "Timeout waiting for Chrome DevTools URL",
                &stderr_lines,
            ));
        }
        let line = line.map_err(|e| format!("Failed to read Chrome stderr: {}", e))?;
        if let Some(url) = line.strip_prefix(prefix) {
            return Ok(url.trim().to_string());
        }
        stderr_lines.push(line);
    }

    Err(chrome_launch_error(
        "Chrome exited before providing DevTools URL",
        &stderr_lines,
    ))
}

fn chrome_launch_error(message: &str, stderr_lines: &[String]) -> String {
    let relevant: Vec<&String> = stderr_lines
        .iter()
        .filter(|l| {
            let lower = l.to_lowercase();
            lower.contains("error")
                || lower.contains("fatal")
                || lower.contains("sandbox")
                || lower.contains("namespace")
                || lower.contains("permission")
                || lower.contains("cannot")
                || lower.contains("failed")
                || lower.contains("abort")
        })
        .collect();

    if relevant.is_empty() {
        if stderr_lines.is_empty() {
            return format!(
                "{} (no stderr output from Chrome)\nHint: try passing --args \"--no-sandbox\" if Chrome crashes silently in your environment",
                message
            );
        }
        let last_lines: Vec<&String> = stderr_lines.iter().rev().take(5).collect();
        return format!(
            "{}\nChrome stderr (last {} lines):\n  {}",
            message,
            last_lines.len(),
            last_lines
                .into_iter()
                .rev()
                .map(|s| s.as_str())
                .collect::<Vec<_>>()
                .join("\n  ")
        );
    }

    let hint = if relevant.iter().any(|l| {
        let lower = l.to_lowercase();
        lower.contains("sandbox") || lower.contains("namespace")
    }) {
        "\nHint: try --args \"--no-sandbox\" (required in containers, VMs, and some Linux setups)"
    } else {
        ""
    };

    format!(
        "{}\nChrome stderr:\n  {}{}",
        message,
        relevant
            .iter()
            .map(|s| s.as_str())
            .collect::<Vec<_>>()
            .join("\n  "),
        hint
    )
}

pub fn find_chrome() -> Option<PathBuf> {
    // 1. Check Chrome downloaded by `agent-browser install`
    if let Some(p) = crate::install::find_installed_chrome() {
        return Some(p);
    }

    // If the cache directory exists but no Chrome was found, warn -- this
    // likely means the cache is corrupted or the directory layout is unexpected.
    let cache_dir = crate::install::get_browsers_dir();
    if cache_dir.exists() {
        let _ = writeln!(
            std::io::stderr(),
            "Warning: Chrome cache directory exists ({}) but no Chrome binary found inside. \
             Falling back to system Chrome. Run `agent-browser install` to re-download.",
            cache_dir.display()
        );
    }

    // 2. Check system-installed Chrome
    #[cfg(target_os = "macos")]
    {
        let candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ];
        for c in &candidates {
            let p = PathBuf::from(c);
            if p.exists() {
                return Some(p);
            }
        }
    }

    #[cfg(target_os = "linux")]
    {
        let candidates = [
            "google-chrome",
            "google-chrome-stable",
            "chromium-browser",
            "chromium",
            "brave-browser",
            "brave-browser-stable",
        ];
        for name in &candidates {
            if let Ok(output) = Command::new("which").arg(name).output() {
                if output.status.success() {
                    let path = String::from_utf8_lossy(&output.stdout).trim().to_string();
                    if !path.is_empty() {
                        return Some(PathBuf::from(path));
                    }
                }
            }
        }
    }

    #[cfg(target_os = "windows")]
    {
        let candidates = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        ];
        if let Ok(local) = std::env::var("LOCALAPPDATA") {
            let chrome = PathBuf::from(&local).join(r"Google\Chrome\Application\chrome.exe");
            if chrome.exists() {
                return Some(chrome);
            }
            let brave =
                PathBuf::from(&local).join(r"BraveSoftware\Brave-Browser\Application\brave.exe");
            if brave.exists() {
                return Some(brave);
            }
        }
        for c in &candidates {
            let p = PathBuf::from(c);
            if p.exists() {
                return Some(p);
            }
        }
    }

    // 3. Fallback: check Puppeteer / Playwright browser caches
    if let Some(p) = find_puppeteer_chrome() {
        return Some(p);
    }
    if let Some(p) = find_playwright_chromium() {
        return Some(p);
    }

    None
}

pub fn read_devtools_active_port(user_data_dir: &Path) -> Option<(u16, String)> {
    let path = user_data_dir.join("DevToolsActivePort");
    let content = std::fs::read_to_string(&path).ok()?;
    let mut lines = content.lines();
    let port: u16 = lines.next()?.trim().parse().ok()?;
    let ws_path = lines
        .next()
        .unwrap_or("/devtools/browser")
        .trim()
        .to_string();
    Some((port, ws_path))
}

pub async fn auto_connect_cdp() -> Result<String, String> {
    let user_data_dirs = get_chrome_user_data_dirs();

    for dir in &user_data_dirs {
        if let Some((port, ws_path)) = read_devtools_active_port(dir) {
            match resolve_cdp_from_active_port(port, &ws_path).await {
                Ok(ws_url) => return Ok(ws_url),
                // Chrome is alive and still showing the permission prompt.
                // Probing further would open another prompt (#1365).
                Err(ActivePortError::AwaitingApproval) => {
                    return Err(format!(
                        "Chrome is waiting for remote-debugging approval on port {}. Approve the prompt in Chrome and retry.",
                        port
                    ));
                }
                Err(ActivePortError::Unreachable(_)) => {}
            }
            // Port is dead — remove the stale file so future runs skip it.
            let stale = dir.join("DevToolsActivePort");
            let _ = std::fs::remove_file(&stale);
        }
    }

    // Fallback: probe common ports
    for port in [9222u16, 9229] {
        if let Ok(ws_url) = discover_cdp_url("127.0.0.1", port, None).await {
            return Ok(ws_url);
        }
    }

    Err("No running Chrome instance found. Launch Chrome with --remote-debugging-port or use --cdp.".to_string())
}

/// Resolve a CDP WebSocket URL from a DevToolsActivePort entry.
///
/// Tries the exact WebSocket path from DevToolsActivePort first (single
/// prompt on M144+), then falls back to legacy HTTP discovery for older
/// Chrome versions. This order avoids triggering duplicate remote-debugging
/// permission prompts (#1210, #1206).
async fn resolve_cdp_from_active_port(port: u16, ws_path: &str) -> Result<String, ActivePortError> {
    resolve_cdp_from_active_port_within(port, ws_path, AUTO_CONNECT_WS_VERIFY_TIMEOUT).await
}

#[derive(Debug, PartialEq)]
enum ActivePortError {
    /// The handshake stayed open past the timeout: Chrome is holding it for
    /// the remote-debugging permission prompt.
    AwaitingApproval,
    Unreachable(String),
}

async fn resolve_cdp_from_active_port_within(
    port: u16,
    ws_path: &str,
    timeout: Duration,
) -> Result<String, ActivePortError> {
    let ws_url = format!("ws://127.0.0.1:{}{}", port, ws_path);
    match verify_ws_endpoint(&ws_url, timeout).await {
        WsVerify::Live => return Ok(ws_url),
        WsVerify::TimedOut => return Err(ActivePortError::AwaitingApproval),
        WsVerify::Failed => {}
    }

    // Pre-M144 fallback: HTTP endpoints (/json/version, /json/list, etc.)
    if let Ok(ws_url) = discover_cdp_url("127.0.0.1", port, None).await {
        return Ok(ws_url);
    }

    Err(ActivePortError::Unreachable(format!(
        "Cannot connect to Chrome on port {}: both direct WebSocket and HTTP discovery failed",
        port
    )))
}

/// How long `--auto-connect` keeps the direct WebSocket handshake open.
/// Chrome 144+ holds the handshake while it shows the remote-debugging
/// permission prompt, so this must leave time to approve it (#1365). It stays
/// below the client's 30s read timeout (`connection::read_timeout_for`) so the
/// daemon answers before the client gives up and retries.
const AUTO_CONNECT_WS_VERIFY_TIMEOUT: Duration = Duration::from_secs(20);

enum WsVerify {
    Live,
    TimedOut,
    Failed,
}

/// Verify that a WebSocket endpoint is a live CDP server by sending
/// `Browser.getVersion` and checking for a valid response.
async fn verify_ws_endpoint(ws_url: &str, timeout: Duration) -> WsVerify {
    use futures_util::{SinkExt, StreamExt};
    use tokio_tungstenite::tungstenite::Message;

    let result = tokio::time::timeout(timeout, async {
        let (mut ws, _) = tokio_tungstenite::connect_async(ws_url).await.ok()?;
        let cmd = r#"{"id":1,"method":"Browser.getVersion"}"#;
        ws.send(Message::Text(cmd.into())).await.ok()?;
        while let Some(Ok(msg)) = ws.next().await {
            if let Message::Text(text) = msg {
                if let Ok(v) = serde_json::from_str::<serde_json::Value>(&text) {
                    if v.get("id").and_then(|id| id.as_u64()) == Some(1) {
                        let _ = ws.close(None).await;
                        return Some(());
                    }
                }
            }
        }
        None
    })
    .await;
    match result {
        Ok(Some(())) => WsVerify::Live,
        Ok(None) => WsVerify::Failed,
        Err(_) => WsVerify::TimedOut,
    }
}

/// Returns the default Chrome user-data directory paths for the current platform.
/// Includes Chrome, Chrome Canary, Chromium, and Brave.
pub fn get_chrome_user_data_dirs() -> Vec<PathBuf> {
    let mut dirs = Vec::new();

    #[cfg(target_os = "macos")]
    {
        if let Some(home) = dirs::home_dir() {
            let base = home.join("Library/Application Support");
            for name in [
                "Google/Chrome",
                "Google/Chrome Canary",
                "Chromium",
                "BraveSoftware/Brave-Browser",
            ] {
                dirs.push(base.join(name));
            }
        }
    }

    #[cfg(target_os = "linux")]
    {
        if let Some(home) = dirs::home_dir() {
            let config = home.join(".config");
            for name in [
                "google-chrome",
                "google-chrome-unstable",
                "chromium",
                "BraveSoftware/Brave-Browser",
            ] {
                dirs.push(config.join(name));
            }
        }
    }

    #[cfg(target_os = "windows")]
    {
        if let Ok(local) = std::env::var("LOCALAPPDATA") {
            let base = PathBuf::from(local);
            for name in [
                r"Google\Chrome\User Data",
                r"Google\Chrome SxS\User Data",
                r"Chromium\User Data",
                r"BraveSoftware\Brave-Browser\User Data",
            ] {
                dirs.push(base.join(name));
            }
        }
    }

    dirs
}

/// Returns true if the given string looks like a Chrome profile name rather than
/// a file path. A profile name contains no `/`, `\`, or `~` characters.
pub fn is_chrome_profile_name(s: &str) -> bool {
    !s.contains('/') && !s.contains('\\') && !s.contains('~')
}

/// Returns the first existing Chrome user-data directory that contains a
/// `Local State` file.
pub fn find_chrome_user_data_dir() -> Option<PathBuf> {
    get_chrome_user_data_dirs()
        .into_iter()
        .find(|dir| dir.join("Local State").is_file())
}

/// A Chrome profile entry parsed from `Local State`.
#[derive(Debug, Clone)]
pub struct ChromeProfile {
    /// The directory name (e.g., "Default", "Profile 1").
    pub directory: String,
    /// The user-visible display name (e.g., "Person 1").
    pub name: String,
}

/// Lists all Chrome profiles found in the given user-data directory by reading
/// the `Local State` JSON file. Returns an empty vec if the file is missing,
/// malformed, or lacks the expected `profile.info_cache` key.
pub fn list_chrome_profiles(user_data_dir: &Path) -> Vec<ChromeProfile> {
    let local_state_path = user_data_dir.join("Local State");
    let content = match std::fs::read_to_string(&local_state_path) {
        Ok(c) => c,
        Err(_) => return Vec::new(),
    };
    let json: serde_json::Value = match serde_json::from_str(&content) {
        Ok(v) => v,
        Err(_) => return Vec::new(),
    };
    let info_cache = match json.get("profile").and_then(|p| p.get("info_cache")) {
        Some(obj) if obj.is_object() => obj.as_object().unwrap(),
        _ => return Vec::new(),
    };

    let mut profiles: Vec<ChromeProfile> = info_cache
        .iter()
        .map(|(dir_name, info)| {
            let display_name = info
                .get("name")
                .and_then(|n| n.as_str())
                .unwrap_or(dir_name)
                .to_string();
            ChromeProfile {
                directory: dir_name.clone(),
                name: display_name,
            }
        })
        .collect();
    profiles.sort_by(|a, b| a.directory.cmp(&b.directory));
    profiles
}

/// Resolves a profile input string to a Chrome profile directory name using
/// three-tier matching:
/// 1. Exact directory name match
/// 2. Case-insensitive display name match (error if ambiguous)
/// 3. Case-insensitive directory name match
///
/// Returns the resolved directory name, or an error with available profiles.
pub fn resolve_chrome_profile(user_data_dir: &Path, input: &str) -> Result<String, String> {
    let profiles = list_chrome_profiles(user_data_dir);

    if profiles.is_empty() {
        return Err(format!(
            "No Chrome profiles found in {}.\n\
             If you meant a directory path, use a full path (e.g., /path/to/profile).",
            user_data_dir.display()
        ));
    }

    // Tier 1: exact directory name match
    if let Some(p) = profiles.iter().find(|p| p.directory == input) {
        return Ok(p.directory.clone());
    }

    // Tier 2: case-insensitive display name match
    let input_lower = input.to_lowercase();
    let display_matches: Vec<&ChromeProfile> = profiles
        .iter()
        .filter(|p| p.name.to_lowercase() == input_lower)
        .collect();
    match display_matches.len() {
        1 => return Ok(display_matches[0].directory.clone()),
        n if n > 1 => {
            return Err(format!(
                "Ambiguous profile name \"{}\". Multiple profiles match:\n{}\n\
                 Use the directory name instead.",
                input,
                format_profile_list(&display_matches)
            ));
        }
        _ => {}
    }

    // Tier 3: case-insensitive directory name match
    if let Some(p) = profiles
        .iter()
        .find(|p| p.directory.to_lowercase() == input_lower)
    {
        return Ok(p.directory.clone());
    }

    let all_profiles: Vec<&ChromeProfile> = profiles.iter().collect();
    Err(format!(
        "Chrome profile \"{}\" not found. Available profiles:\n{}\n\
         If you meant a directory path, use a full path (e.g., /path/to/profile).",
        input,
        format_profile_list(&all_profiles)
    ))
}

fn format_profile_list(profiles: &[&ChromeProfile]) -> String {
    profiles
        .iter()
        .map(|p| format!("  {} ({})", p.directory, p.name))
        .collect::<Vec<_>>()
        .join("\n")
}

/// Directories to exclude when copying a Chrome profile. These are large
/// non-auth directories that are not needed for reusing login state.
const PROFILE_COPY_EXCLUDE_DIRS: &[&str] = &[
    "Cache",
    "Code Cache",
    "GPUCache",
    "Service Worker",
    "blob_storage",
    "File System",
    "GCM Store",
    "optimization_guide",
    "ShaderCache",
    "component_crx_cache",
];

/// Copies a Chrome profile subdirectory and `Local State` to a temp directory
/// with a two-level structure suitable for `--user-data-dir`. Returns the temp
/// directory path on success.
///
/// The copy is best-effort: individual file failures (e.g., `SingletonLock`)
/// are skipped with a warning. If the source profile directory is missing or
/// the temp dir cannot be created, returns an error after cleaning up.
pub fn copy_chrome_profile(
    user_data_dir: &Path,
    profile_directory: &str,
) -> Result<PathBuf, String> {
    let temp_dir =
        std::env::temp_dir().join(format!("agent-browser-profile-{}", uuid::Uuid::new_v4()));
    std::fs::create_dir_all(&temp_dir)
        .map_err(|e| format!("Failed to create temp profile dir: {}", e))?;

    // Copy Local State (non-fatal if missing or unreadable)
    let local_state_src = user_data_dir.join("Local State");
    if let Err(e) = std::fs::copy(&local_state_src, temp_dir.join("Local State")) {
        let _ = writeln!(
            std::io::stderr(),
            "Warning: could not copy Local State from {}: {}",
            local_state_src.display(),
            e
        );
    }

    // Copy profile subdirectory
    let src_profile = user_data_dir.join(profile_directory);
    if !src_profile.is_dir() {
        let _ = std::fs::remove_dir_all(&temp_dir);
        return Err(format!(
            "Profile directory not found: {}",
            src_profile.display()
        ));
    }
    let dst_profile = temp_dir.join(profile_directory);
    if let Err(e) = copy_dir_recursive(&src_profile, &dst_profile) {
        let _ = std::fs::remove_dir_all(&temp_dir);
        return Err(format!("Failed to copy profile: {}", e));
    }

    Ok(temp_dir)
}

/// Recursively copies a directory, skipping entries in [`PROFILE_COPY_EXCLUDE_DIRS`].
/// Individual file copy failures are logged to stderr but do not fail the operation.
fn copy_dir_recursive(src: &Path, dst: &Path) -> Result<(), String> {
    std::fs::create_dir_all(dst)
        .map_err(|e| format!("Failed to create directory {}: {}", dst.display(), e))?;

    let entries = std::fs::read_dir(src)
        .map_err(|e| format!("Failed to read directory {}: {}", src.display(), e))?;

    for entry in entries {
        let entry = match entry {
            Ok(e) => e,
            Err(e) => {
                let _ = writeln!(
                    std::io::stderr(),
                    "Warning: failed to read entry in {}: {}",
                    src.display(),
                    e
                );
                continue;
            }
        };

        let name = entry.file_name();
        let name_str = name.to_string_lossy();
        let src_path = entry.path();
        let dst_path = dst.join(&name);

        let file_type = match entry.file_type() {
            Ok(ft) => ft,
            Err(e) => {
                let _ = writeln!(
                    std::io::stderr(),
                    "Warning: failed to get file type for {}: {}",
                    src_path.display(),
                    e
                );
                continue;
            }
        };

        if file_type.is_dir() {
            if PROFILE_COPY_EXCLUDE_DIRS.contains(&name_str.as_ref()) {
                continue;
            }
            copy_dir_recursive(&src_path, &dst_path)?;
        } else if let Err(e) = std::fs::copy(&src_path, &dst_path) {
            let _ = writeln!(
                std::io::stderr(),
                "Warning: failed to copy {}: {}",
                src_path.display(),
                e
            );
        }
    }

    Ok(())
}

/// Returns true if Chrome's sandbox should be disabled because the environment
/// doesn't support it (containers, VMs, CI runners, running as root).
fn should_disable_sandbox(existing_args: &[String]) -> bool {
    if existing_args.iter().any(|a| a == "--no-sandbox") {
        return false; // already set by user
    }

    // CI environments (GitHub Actions, GitLab CI, etc.) often lack user namespace
    // support due to AppArmor or kernel restrictions.
    if std::env::var("CI").is_ok() {
        return true;
    }

    #[cfg(unix)]
    {
        // Root user -- standard container default, Chrome sandbox requires non-root
        if unsafe { libc::geteuid() } == 0 {
            return true;
        }

        // Docker container
        if Path::new("/.dockerenv").exists() {
            return true;
        }

        // Podman container
        if Path::new("/run/.containerenv").exists() {
            return true;
        }

        // Generic container detection: cgroup contains docker/kubepods/lxc
        if let Ok(cgroup) = std::fs::read_to_string("/proc/1/cgroup") {
            if cgroup.contains("docker") || cgroup.contains("kubepods") || cgroup.contains("lxc") {
                return true;
            }
        }
    }

    false
}

#[cfg(any(target_os = "linux", test))]
const MIN_DEV_SHM_AVAILABLE_BYTES: u64 = 256 * 1024 * 1024;

#[cfg(target_os = "linux")]
fn available_filesystem_bytes(path: &Path) -> Option<u64> {
    let path = std::ffi::CString::new(path.as_os_str().as_bytes()).ok()?;
    let mut stats = std::mem::MaybeUninit::<libc::statvfs>::uninit();

    // SAFETY: `path` is a valid, NUL-terminated C string and `stats` points to
    // writable storage for a `statvfs` value. A successful call initializes it.
    if unsafe { libc::statvfs(path.as_ptr(), stats.as_mut_ptr()) } != 0 {
        return None;
    }

    let stats = unsafe { stats.assume_init() };
    let available_bytes = u128::from(stats.f_bavail).saturating_mul(u128::from(stats.f_frsize));
    Some(u64::try_from(available_bytes).unwrap_or(u64::MAX))
}

#[cfg(any(target_os = "linux", test))]
fn dev_shm_is_too_small(available_bytes: u64) -> bool {
    available_bytes < MIN_DEV_SHM_AVAILABLE_BYTES
}

/// Returns true if Chrome should use disk instead of `/dev/shm` for shared memory.
/// Prefer the actual filesystem capacity over environment markers because some
/// container runtimes expose no conventional marker and others provision a large mount.
fn should_disable_dev_shm(existing_args: &[String]) -> bool {
    if existing_args.iter().any(|a| a == "--disable-dev-shm-usage") {
        return false;
    }

    #[cfg(target_os = "linux")]
    if let Some(available_bytes) = available_filesystem_bytes(Path::new("/dev/shm")) {
        return dev_shm_is_too_small(available_bytes);
    }

    // Preserve the existing safe fallback when `/dev/shm` cannot be inspected.
    if std::env::var("CI").is_ok() {
        return true;
    }

    #[cfg(unix)]
    {
        if unsafe { libc::geteuid() } == 0 {
            return true;
        }
        if Path::new("/.dockerenv").exists() || Path::new("/run/.containerenv").exists() {
            return true;
        }
        if let Ok(cgroup) = std::fs::read_to_string("/proc/1/cgroup") {
            if cgroup.contains("docker") || cgroup.contains("kubepods") || cgroup.contains("lxc") {
                return true;
            }
        }
    }

    false
}

/// Search Puppeteer's browser cache for a Chrome binary.
/// Puppeteer v19+ stores Chrome in ~/.cache/puppeteer/chrome/<platform>-<version>/
fn find_puppeteer_chrome() -> Option<PathBuf> {
    let mut search_dirs = Vec::new();

    if let Ok(custom) = std::env::var("PUPPETEER_CACHE_DIR") {
        search_dirs.push(PathBuf::from(custom).join("chrome"));
    }

    if let Some(home) = dirs::home_dir() {
        search_dirs.push(home.join(".cache/puppeteer/chrome"));
    }

    for dir in &search_dirs {
        if !dir.is_dir() {
            continue;
        }
        if let Ok(entries) = std::fs::read_dir(dir) {
            let mut matches: Vec<PathBuf> = entries
                .filter_map(|e| e.ok())
                .filter(|e| e.path().is_dir())
                .filter_map(|e| {
                    let candidate = build_puppeteer_binary_path(&e.path());
                    if candidate.exists() {
                        Some(candidate)
                    } else {
                        None
                    }
                })
                .collect();
            matches.sort();
            matches.reverse();
            if let Some(p) = matches.into_iter().next() {
                return Some(p);
            }
        }
    }

    None
}

#[cfg(target_os = "linux")]
fn build_puppeteer_binary_path(version_dir: &Path) -> PathBuf {
    version_dir.join("chrome-linux64/chrome")
}

#[cfg(target_os = "macos")]
fn build_puppeteer_binary_path(version_dir: &Path) -> PathBuf {
    // Puppeteer uses chrome-mac-arm64 or chrome-mac-x64 depending on arch
    let arm = version_dir.join(
        "chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
    );
    if arm.exists() {
        return arm;
    }
    version_dir.join(
        "chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
    )
}

#[cfg(target_os = "windows")]
fn build_puppeteer_binary_path(version_dir: &Path) -> PathBuf {
    version_dir.join(r"chrome-win64\chrome.exe")
}

#[cfg(not(any(target_os = "macos", target_os = "linux", target_os = "windows")))]
fn build_puppeteer_binary_path(version_dir: &Path) -> PathBuf {
    version_dir.join("chrome")
}

/// Search Playwright's browser cache for a Chromium binary.
/// Legacy fallback for users who previously installed Chromium via Playwright.
fn find_playwright_chromium() -> Option<PathBuf> {
    let mut search_dirs = Vec::new();

    if let Ok(custom) = std::env::var("PLAYWRIGHT_BROWSERS_PATH") {
        search_dirs.push(PathBuf::from(custom));
    }

    if let Some(home) = dirs::home_dir() {
        search_dirs.push(home.join(".cache/ms-playwright"));
    }

    for dir in &search_dirs {
        if !dir.is_dir() {
            continue;
        }
        if let Ok(entries) = std::fs::read_dir(dir) {
            let mut matches: Vec<PathBuf> = entries
                .filter_map(|e| e.ok())
                .filter(|e| {
                    e.file_name()
                        .to_str()
                        .map(|n| n.starts_with("chromium-"))
                        .unwrap_or(false)
                })
                .filter_map(|e| {
                    let candidate = build_playwright_binary_path(&e.path());
                    if candidate.exists() {
                        Some(candidate)
                    } else {
                        None
                    }
                })
                .collect();
            // Sort descending so the newest version wins
            matches.sort();
            matches.reverse();
            if let Some(p) = matches.into_iter().next() {
                return Some(p);
            }
        }
    }

    None
}

#[cfg(target_os = "linux")]
fn build_playwright_binary_path(chromium_dir: &Path) -> PathBuf {
    // Playwright's Linux layout is chrome-linux/chrome; chrome-linux64 is
    // the Chrome-for-Testing naming kept as a fallback.
    let standard = chromium_dir.join("chrome-linux/chrome");
    if standard.exists() {
        return standard;
    }
    chromium_dir.join("chrome-linux64/chrome")
}

#[cfg(target_os = "macos")]
fn build_playwright_binary_path(chromium_dir: &Path) -> PathBuf {
    chromium_dir.join("chrome-mac/Chromium.app/Contents/MacOS/Chromium")
}

#[cfg(target_os = "windows")]
fn build_playwright_binary_path(chromium_dir: &Path) -> PathBuf {
    chromium_dir.join("chrome-win/chrome.exe")
}

fn expand_tilde(path: &str) -> String {
    if let Some(rest) = path.strip_prefix('~') {
        if let Some(home) = dirs::home_dir() {
            return home
                .join(rest.strip_prefix('/').unwrap_or(rest))
                .to_string_lossy()
                .to_string();
        }
    }
    path.to_string()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_utils::EnvGuard;

    #[test]
    fn test_dev_shm_capacity_threshold() {
        assert!(dev_shm_is_too_small(64 * 1024 * 1024));
        assert!(dev_shm_is_too_small(128 * 1024 * 1024));
        assert!(!dev_shm_is_too_small(256 * 1024 * 1024));
        assert!(!dev_shm_is_too_small(1024 * 1024 * 1024));
    }

    #[test]
    fn test_existing_disable_dev_shm_arg_is_not_duplicated() {
        assert!(!should_disable_dev_shm(&[
            "--disable-dev-shm-usage".to_string()
        ]));
    }

    #[cfg(unix)]
    #[test]
    fn test_stderr_drained_after_port_readiness() {
        use std::os::unix::fs::PermissionsExt;

        let fixture = tempfile::tempdir().unwrap();
        let executable = fixture.path().join("chrome");
        std::fs::write(
            &executable,
            r#"#!/bin/sh
set -eu
for arg do
    case "$arg" in --user-data-dir=*) profile="${arg#*=}" ;; esac
done
printf '9222\n/devtools/browser/stderr-test\n' > "$profile/DevToolsActivePort"
for round in 1 2; do
    while [ ! -f "$profile/request-$round" ]; do sleep 0.01; done
    printf '\377' >&2
    head -c 2097152 /dev/zero >&2
    touch "$profile/drained-$round"
done
exec sleep 60
"#,
        )
        .unwrap();
        std::fs::set_permissions(&executable, std::fs::Permissions::from_mode(0o700)).unwrap();
        let options = LaunchOptions {
            headless: true,
            ..Default::default()
        };
        let mut chrome = try_launch_chrome(&executable, &options).unwrap();
        let profile = chrome.temp_user_data_dir.clone().unwrap();
        assert_eq!(
            chrome.ws_url,
            "ws://127.0.0.1:9222/devtools/browser/stderr-test"
        );
        for round in 1..=2 {
            std::fs::write(profile.join(format!("request-{round}")), b"").unwrap();
            let drained = profile.join(format!("drained-{round}"));
            let deadline = std::time::Instant::now() + Duration::from_secs(5);
            while !drained.exists() && std::time::Instant::now() < deadline {
                assert!(
                    !chrome.has_exited(),
                    "writer exited before completing stderr"
                );
                std::thread::sleep(Duration::from_millis(10));
            }
            assert!(
                drained.exists(),
                "stderr burst {round} blocked after readiness"
            );
            assert!(!chrome.has_exited());
        }
        drop(chrome);
        assert!(!profile.exists());
    }

    fn prepared_nss_home() -> PreparedNssHome {
        let path = std::env::temp_dir().join(format!(
            "agent-browser-prepared-nss-test-{}",
            uuid::Uuid::new_v4()
        ));
        std::fs::create_dir_all(&path).unwrap();
        PreparedNssHome {
            inner: Arc::new(PreparedNssHomeInner { path }),
        }
    }

    #[test]
    fn test_resolve_prepared_nss_home_without_ca_returns_none() {
        assert!(resolve_prepared_nss_home(&LaunchOptions::default())
            .unwrap()
            .is_none());
    }

    #[test]
    fn test_resolve_prepared_nss_home_reuses_prepared_home() {
        let prepared = prepared_nss_home();
        let expected_path = prepared.path().to_path_buf();
        let options = LaunchOptions {
            prepared_nss_home: Some(prepared),
            ca_cert: Some("/path/that/must/not/be/read".to_string()),
            ..Default::default()
        };

        let resolved = resolve_prepared_nss_home(&options).unwrap().unwrap();
        assert_eq!(resolved.path(), expected_path);
    }

    #[test]
    fn test_resolve_prepared_nss_home_surfaces_ca_load_error() {
        let missing = std::env::temp_dir()
            .join(format!("missing-ca-{}", uuid::Uuid::new_v4()))
            .display()
            .to_string();
        let options = LaunchOptions {
            ca_cert: Some(missing),
            ..Default::default()
        };

        let result = resolve_prepared_nss_home(&options);
        assert!(matches!(
            result,
            Err(error) if error.contains("Failed to read CA certificate")
        ));
    }

    #[cfg(unix)]
    fn spawn_noop_child() -> Child {
        Command::new("/bin/sh")
            .args(["-c", "exit 0"])
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()
            .unwrap()
    }

    #[cfg(windows)]
    fn spawn_noop_child() -> Child {
        let cmd = PathBuf::from(std::env::var_os("SystemRoot").unwrap()).join("System32/cmd.exe");
        Child::spawn(&cmd, &["/C".into(), "exit 0".into()], false).unwrap()
    }

    #[test]
    fn test_find_chrome_returns_some_on_host() {
        // This test only makes sense on systems with Chrome installed
        if cfg!(target_os = "macos") || cfg!(target_os = "linux") {
            let result = find_chrome();
            // Don't assert Some -- CI may not have Chrome
            if let Some(path) = result {
                assert!(path.exists());
            }
        }
    }

    #[test]
    fn test_expand_tilde() {
        let expanded = expand_tilde("~/test/path");
        assert!(!expanded.starts_with('~'));
        assert!(expanded.ends_with("test/path"));
    }

    #[test]
    fn test_expand_tilde_no_tilde() {
        assert_eq!(expand_tilde("/absolute/path"), "/absolute/path");
    }

    #[test]
    fn test_read_devtools_active_port_missing() {
        let result = read_devtools_active_port(Path::new("/nonexistent"));
        assert!(result.is_none());
    }

    #[test]
    fn test_should_disable_sandbox_skips_if_already_set() {
        let args = vec!["--headless=new".to_string(), "--no-sandbox".to_string()];
        assert!(!should_disable_sandbox(&args));
    }

    #[test]
    fn test_chrome_launch_error_no_stderr() {
        let msg = chrome_launch_error("Chrome exited", &[]);
        assert!(msg.contains("no stderr output"));
        assert!(msg.contains("Hint:"));
        assert!(msg.contains("--no-sandbox"));
    }

    #[test]
    fn test_chrome_launch_error_with_sandbox_hint() {
        let lines = vec![
            "some log line".to_string(),
            "Failed to move to new namespace: sandbox error".to_string(),
        ];
        let msg = chrome_launch_error("Chrome exited", &lines);
        assert!(msg.contains("sandbox error"));
        assert!(msg.contains("Hint:"));
        assert!(msg.contains("--no-sandbox"));
    }

    #[test]
    fn test_chrome_launch_error_generic() {
        let lines = vec!["info line".to_string(), "another info line".to_string()];
        let msg = chrome_launch_error("Chrome exited", &lines);
        assert!(msg.contains("last 2 lines"));
    }

    #[test]
    fn test_find_playwright_chromium_nonexistent() {
        let guard = EnvGuard::new(&["PLAYWRIGHT_BROWSERS_PATH", "HOME", "USERPROFILE"]);
        guard.set("PLAYWRIGHT_BROWSERS_PATH", "/nonexistent/path");

        let temp_home = std::env::temp_dir().join(format!(
            "agent-browser-test-home-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .expect("system clock should be after unix epoch")
                .as_nanos()
        ));
        std::fs::create_dir_all(&temp_home).expect("temp home should be created");
        let temp_home = temp_home.to_string_lossy().to_string();
        guard.set("HOME", &temp_home);
        guard.set("USERPROFILE", &temp_home);

        let result = find_playwright_chromium();
        assert!(result.is_none());
    }

    #[test]
    fn test_build_args_headless_includes_headless_flag() {
        let opts = LaunchOptions {
            headless: true,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(result.args.iter().any(|a| a == "--headless=new"));
        assert!(result.args.iter().any(|a| a == "--hide-scrollbars"));
        assert!(result
            .args
            .iter()
            .any(|a| a == "--enable-unsafe-swiftshader"));
        assert!(result.args.iter().any(|a| a == "--window-size=1280,720"));
        // Temp dir created when no profile
        assert!(result.temp_user_data_dir.is_some());
        let dir = result.temp_user_data_dir.unwrap();
        assert!(dir.exists());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_build_args_headed_no_headless_flag() {
        let opts = LaunchOptions {
            headless: false,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(!result.args.iter().any(|a| a.contains("--headless")));
        assert!(!result.args.iter().any(|a| a == "--hide-scrollbars"));
        assert!(!result
            .args
            .iter()
            .any(|a| a == "--enable-unsafe-swiftshader"));
        assert!(!result.args.iter().any(|a| a.starts_with("--window-size=")));
        // Temp dir created when no profile
        assert!(result.temp_user_data_dir.is_some());
        let dir = result.temp_user_data_dir.unwrap();
        assert!(dir.exists());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_build_args_temp_user_data_dir_created() {
        let opts = LaunchOptions::default();
        let result = build_chrome_args(&opts).unwrap();
        let dir = result.temp_user_data_dir.as_ref().unwrap();
        assert!(dir.exists());
        assert!(result
            .args
            .iter()
            .any(|a| a.starts_with("--user-data-dir=")));
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn test_build_args_profile_no_temp_dir() {
        let opts = LaunchOptions {
            profile: Some("/tmp/my-profile".to_string()),
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(result.temp_user_data_dir.is_none());
        assert!(result
            .args
            .iter()
            .any(|a| a == "--user-data-dir=/tmp/my-profile"));
    }

    #[test]
    fn test_build_args_custom_window_size_not_overridden() {
        let opts = LaunchOptions {
            headless: true,
            args: vec!["--window-size=1920,1080".to_string()],
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(!result.args.iter().any(|a| a == "--window-size=1280,720"));
        assert!(result.args.iter().any(|a| a == "--window-size=1920,1080"));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_hide_scrollbars_false_suppresses_default_hide_scrollbars() {
        let opts = LaunchOptions {
            headless: true,
            hide_scrollbars: false,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(
            !result.args.iter().any(|a| a == "--hide-scrollbars"),
            "--hide-scrollbars false should suppress agent-browser's default hide switch"
        );
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_start_maximized_suppresses_default_window_size() {
        let opts = LaunchOptions {
            headless: true,
            args: vec!["--start-maximized".to_string()],
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(!result.args.iter().any(|a| a == "--window-size=1280,720"));
        assert!(result.args.iter().any(|a| a == "--start-maximized"));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_disables_translate() {
        let opts = LaunchOptions::default();
        let result = build_chrome_args(&opts).unwrap();
        assert!(result
            .args
            .iter()
            .any(|a| a.contains("--disable-features") && a.contains("Translate")));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_webgpu_default_off() {
        let opts = LaunchOptions::default();
        let result = build_chrome_args(&opts).unwrap();
        assert!(!result.args.iter().any(|a| a == "--enable-unsafe-webgpu"));
        assert!(!result.args.iter().any(|a| a.contains("Vulkan")));
        assert!(!result
            .args
            .iter()
            .any(|a| a.starts_with("--use-webgpu-adapter")));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_restrict_webrtc_enforces_safe_policy() {
        let opts = LaunchOptions {
            restrict_webrtc: true,
            args: vec!["--force-webrtc-ip-handling-policy=default".to_string()],
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        let policies: Vec<&String> = result
            .args
            .iter()
            .filter(|arg| arg.starts_with("--force-webrtc-ip-handling-policy="))
            .collect();
        assert_eq!(
            policies,
            vec![&"--force-webrtc-ip-handling-policy=disable_non_proxied_udp".to_string()]
        );
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_webgpu_includes_webgpu_flags() {
        let opts = LaunchOptions {
            webgpu: true,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(result.args.iter().any(|a| a == "--enable-unsafe-webgpu"));
        if cfg!(target_os = "linux") {
            let features: Vec<&str> = result
                .args
                .iter()
                .find_map(|arg| arg.strip_prefix("--enable-features="))
                .unwrap()
                .split(',')
                .collect();
            assert!(features.contains(&"NetworkService"));
            assert!(features.contains(&"NetworkServiceInProcess"));
            assert!(features.contains(&"Vulkan"));
            assert!(result.args.iter().any(|a| a == "--use-angle=vulkan"));
            assert!(result.args.iter().any(|a| a == "--use-vulkan=swiftshader"));
            assert!(result
                .args
                .iter()
                .any(|a| a == "--use-webgpu-adapter=swiftshader"));
            assert!(result.args.iter().any(|a| a == "--disable-vulkan-surface"));
        } else {
            assert!(!result
                .args
                .iter()
                .any(|a| a.starts_with("--use-webgpu-adapter")));
        }
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_merges_user_enable_features() {
        let opts = LaunchOptions {
            webgpu: true,
            args: vec![
                "--enable-features=Foo,Bar".to_string(),
                "--some-other-flag".to_string(),
                // Duplicate of a preset feature must not repeat.
                "--enable-features=NetworkService".to_string(),
            ],
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        let flags: Vec<&String> = result
            .args
            .iter()
            .filter(|a| a.starts_with("--enable-features="))
            .collect();
        assert_eq!(flags.len(), 1, "user features must merge, not clobber");
        let features: Vec<&str> = flags[0]
            .strip_prefix("--enable-features=")
            .unwrap()
            .split(',')
            .collect();
        assert!(features.contains(&"NetworkService"));
        assert!(features.contains(&"Foo"));
        assert!(features.contains(&"Bar"));
        if cfg!(target_os = "linux") {
            assert!(
                features.contains(&"Vulkan"),
                "user --enable-features must not drop the WebGPU preset's Vulkan"
            );
        }
        assert_eq!(
            features.iter().filter(|f| **f == "NetworkService").count(),
            1
        );
        assert!(result.args.iter().any(|a| a == "--some-other-flag"));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn test_xvfb_applicable_tracks_effective_headed_mode() {
        // Plain headless: no display needed.
        assert!(!xvfb_applicable(&LaunchOptions::default()));
        // Headed: needs a display.
        assert!(xvfb_applicable(&LaunchOptions {
            headless: false,
            ..Default::default()
        }));
        // Nominally headless with extensions: build_chrome_args suppresses
        // --headless, so this runs headed and needs a display too.
        assert!(xvfb_applicable(&LaunchOptions {
            headless: true,
            extensions: Some(vec!["/tmp/ext".to_string()]),
            ..Default::default()
        }));
        // An empty extension list does not force headed mode.
        assert!(!xvfb_applicable(&LaunchOptions {
            headless: true,
            extensions: Some(Vec::new()),
            ..Default::default()
        }));
    }

    #[test]
    fn test_effectively_headless_tracks_extension_forced_headed_mode() {
        assert!(LaunchOptions::default().effectively_headless());
        assert!(!LaunchOptions {
            headless: false,
            ..Default::default()
        }
        .effectively_headless());
        assert!(!LaunchOptions {
            headless: true,
            extensions: Some(vec!["/tmp/ext".to_string()]),
            ..Default::default()
        }
        .effectively_headless());
        assert!(LaunchOptions {
            headless: true,
            extensions: Some(Vec::new()),
            ..Default::default()
        }
        .effectively_headless());
    }

    #[test]
    fn test_build_args_single_enable_features_flag() {
        let opts = LaunchOptions {
            webgpu: true,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        // Chrome only honors the last --enable-features switch, so the preset
        // must never emit more than one.
        let count = result
            .args
            .iter()
            .filter(|a| a.starts_with("--enable-features="))
            .count();
        assert_eq!(count, 1);
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_enables_webmcp_by_default() {
        let result = build_chrome_args(&LaunchOptions::default()).unwrap();
        let features = result
            .args
            .iter()
            .find(|arg| arg.starts_with("--enable-features="))
            .unwrap();
        assert!(features.contains("WebMCPTesting"));
        assert!(features.contains("DevToolsWebMCPSupport"));
    }

    #[test]
    fn test_build_args_webmcp_opt_out() {
        let result = build_chrome_args(&LaunchOptions {
            webmcp: false,
            ..Default::default()
        })
        .unwrap();
        let features = result
            .args
            .iter()
            .find(|arg| arg.starts_with("--enable-features="))
            .unwrap();
        assert!(!features.contains("WebMCPTesting"));
        assert!(!features.contains("DevToolsWebMCPSupport"));
    }

    #[test]
    fn test_build_args_headless_with_extensions_skips_headless_flag() {
        let opts = LaunchOptions {
            headless: true,
            extensions: Some(vec!["/tmp/my-ext".to_string()]),
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(
            !result.args.iter().any(|a| a.contains("--headless")),
            "headless flag should be omitted when extensions are present"
        );
        assert!(
            !result.args.iter().any(|a| a == "--hide-scrollbars"),
            "scrollbars should remain visible when extensions force headed mode"
        );
        assert!(
            !result.args.iter().any(|a| a.contains("--window-size")),
            "window-size should be omitted when extensions force headed mode"
        );
        assert!(result
            .args
            .iter()
            .any(|a| a.starts_with("--load-extension=")));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_headed_with_extensions_no_headless_flag() {
        let opts = LaunchOptions {
            headless: false,
            extensions: Some(vec!["/tmp/my-ext".to_string()]),
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(
            !result.args.iter().any(|a| a.contains("--headless")),
            "headless flag should not be present in headed mode"
        );
        assert!(result
            .args
            .iter()
            .any(|a| a.starts_with("--load-extension=")));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_ignore_https_errors_includes_flag() {
        let opts = LaunchOptions {
            ignore_https_errors: true,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(result
            .args
            .iter()
            .any(|a| a == "--ignore-certificate-errors"));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_ignore_https_errors_default_no_flag() {
        let opts = LaunchOptions::default();
        let result = build_chrome_args(&opts).unwrap();
        assert!(!result
            .args
            .iter()
            .any(|a| a == "--ignore-certificate-errors"));
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_chrome_process_drop_cleans_temp_dir() {
        let dir = std::env::temp_dir().join(format!(
            "agent-browser-chrome-drop-test-{}",
            uuid::Uuid::new_v4()
        ));
        let _ = std::fs::create_dir_all(&dir);
        assert!(dir.exists());

        {
            // Simulate a ChromeProcess with a temp dir but a dummy child.
            // We can't actually spawn Chrome here, but we can verify the Drop
            // logic by creating a small helper process.
            let child = spawn_noop_child();
            let _process = ChromeProcess {
                child,
                ws_url: String::new(),
                temp_user_data_dir: Some(dir.clone()),
                temp_nss_home: None,
                #[cfg(unix)]
                pgid: None,
                #[cfg(target_os = "linux")]
                xvfb: None,
            };
            // _process dropped here
        }

        assert!(!dir.exists(), "Temp dir should be cleaned up on drop");
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn test_write_xauth_file_wildcard_cookie_record() {
        use std::os::unix::fs::PermissionsExt;

        let path = std::env::temp_dir().join(format!("xauth-test-{}", uuid::Uuid::new_v4()));
        write_xauth_file(&path).unwrap();

        let mode = std::fs::metadata(&path).unwrap().permissions().mode();
        assert_eq!(mode & 0o777, 0o600, "authority file must be private");

        let bytes = std::fs::read(&path).unwrap();
        // family=FamilyWild, empty address, empty number
        assert_eq!(&bytes[..6], &[0xff, 0xff, 0, 0, 0, 0]);
        // name length + MIT-MAGIC-COOKIE-1
        assert_eq!(&bytes[6..8], &18u16.to_be_bytes());
        assert_eq!(&bytes[8..26], b"MIT-MAGIC-COOKIE-1");
        // 16-byte cookie
        assert_eq!(&bytes[26..28], &16u16.to_be_bytes());
        assert_eq!(bytes.len(), 28 + 16);

        // A second write must produce a different cookie.
        let path2 = std::env::temp_dir().join(format!("xauth-test-{}", uuid::Uuid::new_v4()));
        write_xauth_file(&path2).unwrap();
        assert_ne!(std::fs::read(&path2).unwrap()[28..], bytes[28..]);

        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(&path2);
    }

    #[test]
    fn test_is_chrome_profile_name_simple() {
        assert!(is_chrome_profile_name("Default"));
        assert!(is_chrome_profile_name("Profile 1"));
        assert!(is_chrome_profile_name(""));
    }

    #[test]
    fn test_is_chrome_profile_name_paths() {
        assert!(!is_chrome_profile_name("/tmp/dir"));
        assert!(!is_chrome_profile_name("~/my-profile"));
        assert!(!is_chrome_profile_name("C:\\Users\\foo"));
        assert!(!is_chrome_profile_name("relative/path"));
    }

    /// Helper to create a fake Chrome user-data dir with a `Local State` file.
    fn create_fake_local_state(base: &Path, profiles: &[(&str, &str)]) {
        let mut info_cache = serde_json::Map::new();
        for (dir_name, display_name) in profiles {
            let mut entry = serde_json::Map::new();
            entry.insert(
                "name".to_string(),
                serde_json::Value::String(display_name.to_string()),
            );
            info_cache.insert(dir_name.to_string(), serde_json::Value::Object(entry));
        }

        let local_state = serde_json::json!({
            "profile": {
                "info_cache": info_cache
            }
        });

        std::fs::create_dir_all(base).unwrap();
        std::fs::write(
            base.join("Local State"),
            serde_json::to_string_pretty(&local_state).unwrap(),
        )
        .unwrap();
    }

    /// RAII guard that removes the temp directory on drop (even on panic).
    struct TempDir(PathBuf);

    impl TempDir {
        fn new(name: &str) -> Self {
            Self(std::env::temp_dir().join(format!(
                "agent-browser-test-{}-{}-{}",
                name,
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            )))
        }
    }

    impl Drop for TempDir {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    impl std::ops::Deref for TempDir {
        type Target = PathBuf;
        fn deref(&self) -> &PathBuf {
            &self.0
        }
    }

    #[test]
    fn test_list_chrome_profiles_valid() {
        let dir = TempDir::new("list-profiles");
        create_fake_local_state(&dir, &[("Default", "Person 1"), ("Profile 1", "Work")]);

        let profiles = list_chrome_profiles(&dir);
        assert_eq!(profiles.len(), 2);
        assert_eq!(profiles[0].directory, "Default");
        assert_eq!(profiles[0].name, "Person 1");
        assert_eq!(profiles[1].directory, "Profile 1");
        assert_eq!(profiles[1].name, "Work");
    }

    #[test]
    fn test_list_chrome_profiles_missing_local_state() {
        let dir = TempDir::new("list-profiles-missing");
        std::fs::create_dir_all(&*dir).unwrap();
        let profiles = list_chrome_profiles(&dir);
        assert!(profiles.is_empty());
    }

    #[test]
    fn test_list_chrome_profiles_malformed_json() {
        let dir = TempDir::new("list-profiles-malformed");
        std::fs::create_dir_all(&*dir).unwrap();
        std::fs::write(dir.join("Local State"), "not json").unwrap();
        let profiles = list_chrome_profiles(&dir);
        assert!(profiles.is_empty());
    }

    #[test]
    fn test_list_chrome_profiles_missing_info_cache() {
        let dir = TempDir::new("list-profiles-no-cache");
        std::fs::create_dir_all(&*dir).unwrap();
        std::fs::write(dir.join("Local State"), r#"{"profile": {}}"#).unwrap();
        let profiles = list_chrome_profiles(&dir);
        assert!(profiles.is_empty());
    }

    #[test]
    fn test_resolve_chrome_profile_exact_directory() {
        let dir = TempDir::new("resolve-exact");
        create_fake_local_state(&dir, &[("Default", "Person 1"), ("Profile 1", "Work")]);

        let result = resolve_chrome_profile(&dir, "Default");
        assert_eq!(result.unwrap(), "Default");
    }

    #[test]
    fn test_resolve_chrome_profile_display_name_case_insensitive() {
        let dir = TempDir::new("resolve-display");
        create_fake_local_state(&dir, &[("Default", "Person 1"), ("Profile 1", "Work")]);

        let result = resolve_chrome_profile(&dir, "work");
        assert_eq!(result.unwrap(), "Profile 1");
    }

    #[test]
    fn test_resolve_chrome_profile_directory_name_case_insensitive() {
        let dir = TempDir::new("resolve-dir-ci");
        create_fake_local_state(&dir, &[("Default", "Person 1"), ("Profile 1", "Work")]);

        let result = resolve_chrome_profile(&dir, "default");
        assert_eq!(result.unwrap(), "Default");
    }

    #[test]
    fn test_resolve_chrome_profile_not_found() {
        let dir = TempDir::new("resolve-notfound");
        create_fake_local_state(&dir, &[("Default", "Person 1")]);

        let result = resolve_chrome_profile(&dir, "Nonexistent");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert!(err.contains("not found"));
        assert!(err.contains("Default"));
        assert!(err.contains("full path"));
    }

    #[test]
    fn test_resolve_chrome_profile_ambiguous_display_name() {
        let dir = TempDir::new("resolve-ambiguous");
        create_fake_local_state(&dir, &[("Default", "Work"), ("Profile 1", "Work")]);

        let result = resolve_chrome_profile(&dir, "Work");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert!(err.contains("Ambiguous"));
        assert!(err.contains("Default"));
        assert!(err.contains("Profile 1"));
    }

    /// Helper to create a fake Chrome profile directory with some files.
    fn create_fake_profile(user_data_dir: &Path, profile_dir: &str) {
        let profile_path = user_data_dir.join(profile_dir);
        std::fs::create_dir_all(profile_path.join("Local Storage/leveldb")).unwrap();
        std::fs::write(profile_path.join("Cookies"), "fake-cookies").unwrap();
        std::fs::write(
            profile_path.join("Local Storage/leveldb/CURRENT"),
            "fake-leveldb",
        )
        .unwrap();
        // Create an excluded directory to verify it's skipped
        std::fs::create_dir_all(profile_path.join("Cache")).unwrap();
        std::fs::write(profile_path.join("Cache/data_0"), "cache-data").unwrap();
    }

    #[test]
    fn test_copy_chrome_profile_structure() {
        let src = TempDir::new("copy-src");
        create_fake_local_state(&src, &[("Default", "Person 1")]);
        create_fake_profile(&src, "Default");

        let temp_path = copy_chrome_profile(&src, "Default").unwrap();
        let temp = TempDir(temp_path);

        assert!(temp.join("Local State").is_file());
        assert!(temp.join("Default/Cookies").is_file());
        assert!(temp.join("Default/Local Storage/leveldb/CURRENT").is_file());
        assert_eq!(
            std::fs::read_to_string(temp.join("Default/Cookies")).unwrap(),
            "fake-cookies"
        );
        assert_eq!(
            std::fs::read_to_string(temp.join("Default/Local Storage/leveldb/CURRENT")).unwrap(),
            "fake-leveldb"
        );
        assert!(!temp.join("Default/Cache").exists());
    }

    #[test]
    fn test_copy_chrome_profile_missing_source() {
        let src = TempDir::new("copy-missing-src");
        std::fs::create_dir_all(&*src).unwrap();

        let result = copy_chrome_profile(&src, "Nonexistent");
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Profile directory not found"));
    }

    #[test]
    fn test_copy_chrome_profile_missing_local_state() {
        let src = TempDir::new("copy-no-ls");
        let profile_path = src.join("Default");
        std::fs::create_dir_all(&profile_path).unwrap();
        std::fs::write(profile_path.join("Cookies"), "data").unwrap();

        let temp_path = copy_chrome_profile(&src, "Default").unwrap();
        let temp = TempDir(temp_path);

        assert!(!temp.join("Local State").exists());
        assert!(temp.join("Default/Cookies").is_file());
    }

    #[test]
    fn test_copy_dir_recursive_excludes() {
        let src = TempDir::new("copy-excludes-src");
        let dst = TempDir::new("copy-excludes-dst");
        std::fs::create_dir_all(src.join("keep")).unwrap();
        std::fs::write(src.join("keep/data"), "keep-data").unwrap();
        for excluded in PROFILE_COPY_EXCLUDE_DIRS {
            std::fs::create_dir_all(src.join(excluded)).unwrap();
            std::fs::write(src.join(excluded).join("file"), "excluded").unwrap();
        }

        copy_dir_recursive(&src, &dst).unwrap();

        assert!(dst.join("keep/data").is_file());
        for excluded in PROFILE_COPY_EXCLUDE_DIRS {
            assert!(
                !dst.join(excluded).exists(),
                "{} should be excluded",
                excluded
            );
        }
    }

    #[test]
    fn test_build_args_use_real_keychain_true() {
        let opts = LaunchOptions {
            use_real_keychain: true,
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(
            !result.args.iter().any(|a| a == "--password-store=basic"),
            "should NOT have --password-store=basic when use_real_keychain is true"
        );
        assert!(
            !result.args.iter().any(|a| a == "--use-mock-keychain"),
            "should NOT have --use-mock-keychain when use_real_keychain is true"
        );
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_use_real_keychain_false_default() {
        let opts = LaunchOptions::default();
        let result = build_chrome_args(&opts).unwrap();
        assert!(
            result.args.iter().any(|a| a == "--password-store=basic"),
            "should have --password-store=basic by default"
        );
        assert!(
            result.args.iter().any(|a| a == "--use-mock-keychain"),
            "should have --use-mock-keychain by default"
        );
        if let Some(ref dir) = result.temp_user_data_dir {
            let _ = std::fs::remove_dir_all(dir);
        }
    }

    #[test]
    fn test_build_args_profile_path_preserves_keychain_flags() {
        let opts = LaunchOptions {
            profile: Some("/tmp/my-profile".to_string()),
            ..Default::default()
        };
        let result = build_chrome_args(&opts).unwrap();
        assert!(result
            .args
            .iter()
            .any(|a| a == "--user-data-dir=/tmp/my-profile"));
        assert!(
            result.args.iter().any(|a| a == "--password-store=basic"),
            "profile path should keep keychain flags"
        );
    }

    // -------------------------------------------------------------------
    // auto_connect_cdp discovery-order tests (#1210, #1206)
    // -------------------------------------------------------------------

    /// When DevToolsActivePort provides a ws_path and the port is reachable,
    /// `resolve_cdp_from_active_port` should return the exact ws_path URL
    /// WITHOUT calling HTTP discovery first.
    #[tokio::test]
    async fn test_resolve_cdp_from_active_port_prefers_ws_path() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::tungstenite::Message as WsMsg;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let ws_path = "/devtools/browser/test-uuid-1234".to_string();

        let server = tokio::spawn(async move {
            // accept: verify_ws_endpoint() WebSocket handshake
            let (stream, _) = listener.accept().await.unwrap();
            let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
            if let Some(Ok(WsMsg::Text(text))) = ws.next().await {
                let req: serde_json::Value = serde_json::from_str(&text).unwrap();
                let id = req.get("id").unwrap();
                let reply = format!(
                    r#"{{"id":{},"result":{{"protocolVersion":"1.3","product":"Chrome/147"}}}}"#,
                    id
                );
                ws.send(WsMsg::Text(reply)).await.unwrap();
            }
            let _ = ws.close(None).await;
        });

        let result = resolve_cdp_from_active_port(port, &ws_path).await;
        assert!(result.is_ok(), "should succeed: {:?}", result);
        let url = result.unwrap();
        assert!(
            url.contains("test-uuid-1234"),
            "should use exact ws_path from DevToolsActivePort, got: {}",
            url
        );
        assert_eq!(url, format!("ws://127.0.0.1:{}{}", port, ws_path));
        server.await.unwrap();
    }

    /// Chrome 144+ holds the WebSocket handshake while the remote-debugging
    /// permission prompt is open. A handshake that completes after a few
    /// seconds must still resolve through the exact ws_path (#1365).
    #[tokio::test]
    async fn test_resolve_cdp_from_active_port_waits_for_permission_prompt() {
        use futures_util::{SinkExt, StreamExt};
        use tokio_tungstenite::tungstenite::Message as WsMsg;

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let ws_path = "/devtools/browser/prompt-uuid".to_string();

        let server = tokio::spawn(async move {
            let (stream, _) = listener.accept().await.unwrap();
            tokio::time::sleep(Duration::from_secs(3)).await;
            let mut ws = tokio_tungstenite::accept_async(stream).await.unwrap();
            if let Some(Ok(WsMsg::Text(text))) = ws.next().await {
                let req: serde_json::Value = serde_json::from_str(&text).unwrap();
                let id = req.get("id").unwrap();
                let reply = format!(
                    r#"{{"id":{},"result":{{"protocolVersion":"1.3","product":"Chrome/148"}}}}"#,
                    id
                );
                ws.send(WsMsg::Text(reply)).await.unwrap();
            }
            let _ = ws.close(None).await;
        });

        let result = resolve_cdp_from_active_port(port, &ws_path).await;
        assert_eq!(result, Ok(format!("ws://127.0.0.1:{}{}", port, ws_path)));
        server.await.unwrap();
    }

    /// When the exact ws_path connection fails, `resolve_cdp_from_active_port`
    /// should fall back to HTTP discovery.
    #[tokio::test]
    async fn test_resolve_cdp_from_active_port_falls_back_to_http_discovery() {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};

        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();

        let server = tokio::spawn(async move {
            // 1st accept: verify_ws_endpoint() ws_path probe — reject (just close)
            let (s1, _) = listener.accept().await.unwrap();
            drop(s1);

            // 2nd accept: HTTP /json/version from discover_cdp_url()
            let (mut s2, _) = listener.accept().await.unwrap();
            let mut buf = [0u8; 2048];
            let _ = s2.read(&mut buf).await;
            let body = format!(
                r#"{{"webSocketDebuggerUrl":"ws://127.0.0.1:{}/devtools/browser/fallback-uuid"}}"#,
                port
            );
            let resp = format!(
                "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nContent-Type: application/json\r\n\r\n{}",
                body.len(),
                body
            );
            s2.write_all(resp.as_bytes()).await.unwrap();
        });

        let result = resolve_cdp_from_active_port(port, "/devtools/browser/nonexistent-uuid").await;
        assert!(result.is_ok(), "should fall back to HTTP: {:?}", result);
        let url = result.unwrap();
        assert!(
            url.contains("fallback-uuid"),
            "should use HTTP discovery fallback, got: {}",
            url
        );
        server.await.unwrap();
    }

    /// When neither ws_path nor HTTP discovery works, return an error.
    #[tokio::test]
    async fn test_resolve_cdp_from_active_port_both_fail() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        drop(listener);

        let result = resolve_cdp_from_active_port(port, "/devtools/browser/dead").await;
        assert!(
            matches!(result, Err(ActivePortError::Unreachable(_))),
            "should fail when nothing is listening: {:?}",
            result
        );
    }

    /// A handshake still held open when the timeout expires means Chrome is
    /// showing the permission prompt. Resolution must stop without HTTP
    /// discovery, which would open a second prompt (#1365).
    #[tokio::test]
    async fn test_resolve_cdp_from_active_port_stops_while_prompt_is_open() {
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();

        let server = tokio::spawn(async move {
            let (held, _) = listener.accept().await.unwrap();
            let second = tokio::time::timeout(Duration::from_secs(2), listener.accept()).await;
            drop(held);
            second.is_ok()
        });

        let result = resolve_cdp_from_active_port_within(
            port,
            "/devtools/browser/prompt",
            Duration::from_millis(300),
        )
        .await;
        assert_eq!(result, Err(ActivePortError::AwaitingApproval));
        assert!(
            !server.await.unwrap(),
            "HTTP discovery must not run while the prompt is open"
        );
    }

    #[test]
    fn auto_connect_wait_stays_below_client_read_timeout() {
        let client_floor = crate::connection::read_timeout_for(&serde_json::json!({}));
        assert!(AUTO_CONNECT_WS_VERIFY_TIMEOUT < client_floor);
    }
}
